'use client';
import { useEffect, useState } from 'react';
import Navbar from '@/components/Navbar';
import EventCard from '@/components/EventCard';
import { getEvents, getPhotos, seedEvents, WeddingEvent } from '@/lib/firebase';

export default function HomepageClient() {
  const [events, setEvents] = useState<WeddingEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      await seedEvents();
      const evts = await getEvents();

      // Attach photo counts and cover photos
      const enriched = await Promise.all(
        evts.map(async (e) => {
          const photos = await getPhotos(e.id);
          return {
            ...e,
            photoCount: photos.length,
            coverPhoto: photos[0]?.url ?? e.coverPhoto,
          };
        })
      );

      // Sort by a fixed order
      const order = ['Engagement', 'Haldi', 'Mehendi', 'Wedding', 'Reception'];
      enriched.sort((a, b) => order.indexOf(a.name) - order.indexOf(b.name));
      setEvents(enriched);
      setLoading(false);
    }
    load();
  }, []);

  const totalPhotos = events.reduce((acc, e) => acc + (e.photoCount ?? 0), 0);

  return (
    <div className="min-h-screen bg-cream">
      <Navbar />

      {/* Hero */}
      <div className="relative bg-gradient-to-b from-warm to-cream px-4 py-20 text-center overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-gold/10 rounded-full blur-3xl" />
        </div>

        <p className="text-xs tracking-[0.18em] uppercase text-gold font-medium mb-4">
          A Celebration of Love
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl text-dark font-light leading-tight">
          Sanjay <em className="italic text-gold not-italic">&</em> Ananya
        </h1>
        <p className="font-serif text-xl text-mid mt-2 italic">Wedding Gallery</p>

        <div className="flex items-center justify-center gap-3 mt-3">
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-gold/60" />
          <p className="text-xs text-mid tracking-widest uppercase">Mumbai · June 2025</p>
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-gold/60" />
        </div>

        {totalPhotos > 0 && (
          <p className="text-sm text-mid mt-4">{totalPhotos} memories captured</p>
        )}
      </div>

      {/* Events grid */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <div className="mb-8">
          <p className="text-xs tracking-[0.14em] uppercase text-gold font-medium mb-1">Browse Memories</p>
          <h2 className="font-serif text-3xl text-dark font-light">Our Wedding Events</h2>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="rounded-2xl overflow-hidden border border-gold-light">
                <div className="h-44 skeleton" />
                <div className="p-4 space-y-2">
                  <div className="h-4 skeleton rounded w-3/4" />
                  <div className="h-3 skeleton rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-5">
            {events.map((event, i) => (
              <EventCard key={event.id} event={event} index={i} />
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-gold-light py-8 text-center">
        <p className="font-serif italic text-mid text-sm">
          Made with love for Sanjay & Ananya ♥
        </p>
      </footer>
    </div>
  );
}
