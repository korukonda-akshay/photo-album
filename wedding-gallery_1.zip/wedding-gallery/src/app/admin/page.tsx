'use client';
import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import Navbar from '@/components/Navbar';
import PhotoUploader from '@/components/PhotoUploader';
import { getEvents, getPhotos, deletePhoto, WeddingEvent, Photo } from '@/lib/firebase';
import { useAdmin } from '@/lib/adminAuth';
import toast from 'react-hot-toast';

export default function AdminPage() {
  const { isAdmin } = useAdmin();
  const router = useRouter();
  const [events, setEvents] = useState<WeddingEvent[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<WeddingEvent | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [photosLoading, setPhotosLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'upload' | 'manage'>('upload');
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) { router.push('/'); }
  }, [isAdmin, router]);

  const loadEvents = useCallback(async () => {
    const evts = await getEvents();
    const order = ['Engagement', 'Haldi', 'Mehendi', 'Wedding', 'Reception'];
    evts.sort((a, b) => order.indexOf(a.name) - order.indexOf(b.name));

    // Attach photo counts
    const enriched = await Promise.all(
      evts.map(async (e) => {
        const ph = await getPhotos(e.id);
        return { ...e, photoCount: ph.length };
      })
    );
    setEvents(enriched);
    if (!selectedEvent && enriched.length > 0) setSelectedEvent(enriched[0]);
    setLoading(false);
  }, [selectedEvent]);

  useEffect(() => { loadEvents(); }, []);

  const loadPhotos = useCallback(async (eventId: string) => {
    setPhotosLoading(true);
    const ph = await getPhotos(eventId);
    setPhotos(ph);
    setPhotosLoading(false);
  }, []);

  useEffect(() => {
    if (selectedEvent) loadPhotos(selectedEvent.id);
  }, [selectedEvent, loadPhotos]);

  const handleDelete = async (photo: Photo) => {
    if (!selectedEvent) return;
    if (!confirm(`Delete "${photo.caption}"?`)) return;
    setDeleting(photo.id);
    try {
      await deletePhoto(selectedEvent.id, photo);
      setPhotos(prev => prev.filter(p => p.id !== photo.id));
      setEvents(prev => prev.map(e =>
        e.id === selectedEvent.id ? { ...e, photoCount: (e.photoCount ?? 1) - 1 } : e
      ));
      toast.success('Photo deleted');
    } catch {
      toast.error('Failed to delete');
    }
    setDeleting(null);
  };

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-cream">
      <Navbar />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Page header */}
        <div className="mb-8">
          <p className="text-xs tracking-[0.14em] uppercase text-gold font-medium mb-1">Admin Panel</p>
          <h1 className="font-serif text-3xl text-dark font-light">Manage Gallery</h1>
          <p className="text-sm text-mid mt-1">Upload and manage photos for Sanjay & Ananya's wedding events.</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left sidebar — event list */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-white border border-gold-light rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-gold-light">
                <p className="text-xs font-medium text-mid uppercase tracking-widest">Events</p>
              </div>
              {loading ? (
                <div className="p-4 space-y-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="h-10 skeleton rounded-lg" />
                  ))}
                </div>
              ) : (
                <div className="p-2">
                  {events.map(event => (
                    <button
                      key={event.id}
                      onClick={() => setSelectedEvent(event)}
                      className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-left transition-all ${
                        selectedEvent?.id === event.id
                          ? 'bg-warm border border-gold-light text-dark'
                          : 'text-mid hover:bg-cream hover:text-dark'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{event.emoji}</span>
                        <span className="text-sm font-medium">{event.name}</span>
                      </div>
                      <span className="text-xs bg-gold-light text-mid px-2 py-0.5 rounded-full">
                        {event.photoCount ?? 0}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick link */}
            {selectedEvent && (
              <Link
                href={`/event/${selectedEvent.id}`}
                className="mt-3 w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-gold-light rounded-xl text-sm text-mid hover:border-gold hover:bg-warm transition-all"
              >
                View public page →
              </Link>
            )}
          </div>

          {/* Right panel */}
          {selectedEvent && (
            <div className="flex-1 min-w-0">
              {/* Event title */}
              <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl">{selectedEvent.emoji}</span>
                <div>
                  <h2 className="font-serif text-2xl text-dark">{selectedEvent.name}</h2>
                  <p className="text-sm text-mid">{selectedEvent.date}</p>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1 border-b border-gold-light mb-6">
                {(['upload', 'manage'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2.5 text-sm capitalize font-medium border-b-2 -mb-px transition-all ${
                      activeTab === tab
                        ? 'border-gold text-dark'
                        : 'border-transparent text-mid hover:text-dark'
                    }`}
                  >
                    {tab === 'upload' ? '📤 Upload Photos' : '🖼 Manage Photos'}
                  </button>
                ))}
              </div>

              {/* Upload tab */}
              {activeTab === 'upload' && (
                <div className="bg-white border border-gold-light rounded-2xl p-6">
                  <PhotoUploader
                    eventId={selectedEvent.id}
                    onUploaded={() => {
                      loadPhotos(selectedEvent.id);
                      loadEvents();
                      toast.success('Gallery updated!');
                    }}
                  />
                </div>
              )}

              {/* Manage tab */}
              {activeTab === 'manage' && (
                <div>
                  {photosLoading ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      {Array.from({ length: 6 }).map((_, i) => (
                        <div key={i} className="skeleton rounded-xl aspect-square" />
                      ))}
                    </div>
                  ) : photos.length === 0 ? (
                    <div className="text-center py-16 bg-white border border-gold-light rounded-2xl">
                      <div className="text-4xl mb-3">{selectedEvent.emoji}</div>
                      <p className="text-sm text-mid">No photos uploaded yet.</p>
                      <button
                        onClick={() => setActiveTab('upload')}
                        className="mt-4 text-sm text-gold hover:text-gold-dark underline"
                      >
                        Upload the first photos →
                      </button>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm text-mid mb-4">
                        {photos.length} photo{photos.length !== 1 ? 's' : ''} — hover to delete
                      </p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                        {photos.map(photo => (
                          <div key={photo.id} className="group relative rounded-xl overflow-hidden border border-gold-light">
                            <Image
                              src={photo.url}
                              alt={photo.caption}
                              width={300}
                              height={300}
                              className="w-full aspect-square object-cover"
                            />
                            {/* Caption */}
                            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                              <p className="text-white text-xs truncate">{photo.caption}</p>
                            </div>
                            {/* Delete button */}
                            <button
                              onClick={() => handleDelete(photo)}
                              disabled={deleting === photo.id}
                              className="absolute top-2 right-2 w-7 h-7 bg-white/90 hover:bg-rose text-mid hover:text-white rounded-full text-xs hidden group-hover:flex items-center justify-center transition-all shadow"
                            >
                              {deleting === photo.id ? '…' : '✕'}
                            </button>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
