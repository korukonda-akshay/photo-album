import type { Metadata } from 'next';
import './globals.css';
import { AdminProvider } from '@/lib/adminAuth';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'Sanjay & Ananya — Wedding Gallery',
  description: 'A beautiful collection of memories from our wedding celebration',
  openGraph: {
    title: 'Sanjay & Ananya Wedding Gallery',
    description: 'Browse our wedding memories — Engagement, Haldi, Mehendi, Wedding & Reception',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AdminProvider>
          {children}
          <Toaster
            position="bottom-center"
            toastOptions={{
              style: {
                fontFamily: "'DM Sans', sans-serif",
                fontSize: '13px',
                background: '#2a1f14',
                color: '#faf7f2',
                borderRadius: '20px',
                padding: '10px 18px',
              },
            }}
          />
        </AdminProvider>
      </body>
    </html>
  );
}
