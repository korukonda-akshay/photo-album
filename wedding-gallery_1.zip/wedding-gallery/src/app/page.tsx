import { Metadata } from 'next';
import HomepageClient from './HomepageClient';

export const metadata: Metadata = {
  title: 'Sanjay & Ananya — Wedding Gallery',
};

export default function HomePage() {
  return <HomepageClient />;
}
