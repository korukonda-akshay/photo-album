'use client';
import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { PhotoProvider, PhotoView } from 'react-photo-view';
import 'react-photo-view/dist/react-photo-view.css';
import Navbar from '@/components/Navbar';
import PhotoUploader from '@/components/PhotoUploader';
import { getEvents, getPhotos, deletePhoto, WeddingEvent, Photo } from '@/lib/firebase';
import { useAdmin } from '@/lib/adminAuth';
import toast from 'react-hot-toast';

export default function EventPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { isAdmin } = useAdmin();

  const [event, setEvent] = useState<WeddingEvent | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploader, setShowUploader] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    const evts = await getEvents();
    const found = evts.find(e => e.id === id);
    if (!found) { router.push('/'); return; }
    setEvent(found);
    const ph = await getPhotos(id);
    setPhotos(ph);
    setLoading(false);
  }, [id, router]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleDelete = async (photo: Photo) => {
    if (!confirm(`Delete "${photo.caption}"? This cannot be undone.`)) return;
    setDeleting(photo.id);
    try {
      await deletePhoto(id, photo);
      setPhotos(prev => prev.filter(p => p.id !== photo.id));
      toast.success('Photo deleted');
    } catch {
      toast.error('Failed to delete photo');
    }
    setDeleting(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream">
        <Navbar />
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="h-8 skeleton rounded w-48 mb-3" />
          <div className="h-4 skeleton rounded w-32 mb-8" />
          <div className="masonry-grid">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="masonry-item">
                <div
                  className="skeleton rounded-xl w-full"
                  style={{ height: i % 3 === 0 ? '240px' : '160px' }}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!event) return null;

  return (
    <div className="min-h-screen bg-cream">
      <Navbar />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <span className="text-3xl">{event.emoji}</span>
              <h1 className="font-serif text-4xl text-dark font-light">{event.name}</h1>
            </div>
            <p className="text-sm text-mid ml-12">
              {event.date}
              {photos.length > 0 && (
                <span> · {photos.length} photo{photos.length !== 1 ? 's' : ''}</span>
              )}
            </p>
            <div className="ml-12 mt-2 h-px w-16 bg-gradient-to-r from-gold/60 to-transparent" />
          </div>

          {isAdmin && (
            <button
              onClick={() => setShowUploader(prev => !prev)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                showUploader
                  ? 'bg-dark text-cream'
                  : 'bg-gold text-white hover:bg-gold-dark'
              }`}
            >
              {showUploader ? '✕ Close Uploader' : '+ Upload Photos'}
            </button>
          )}
        </div>

        {/* Upload panel */}
        {isAdmin && showUploader && (
          <div className="mb-8 bg-white border border-gold-light rounded-2xl p-6">
            <h2 className="font-serif text-xl text-dark mb-4">
              Upload to <span className="italic text-gold">{event.name}</span>
            </h2>
            <PhotoUploader
              eventId={id}
              onUploaded={() => {
                loadData();
                setShowUploader(false);
              }}
            />
          </div>
        )}

        {/* Empty state */}
        {photos.length === 0 && (
          <div className="text-center py-24">
            <div className="text-5xl mb-4">{event.emoji}</div>
            <h3 className="font-serif text-2xl text-dark mb-2">No photos yet</h3>
            <p className="text-sm text-mid">
              {isAdmin
                ? 'Click "Upload Photos" above to add the first photos to this event.'
                : 'Photos will appear here once uploaded by the admin.'}
            </p>
          </div>
        )}

        {/* Masonry photo grid with lightbox */}
        {photos.length > 0 && (
          <PhotoProvider>
            <div className="masonry-grid">
              {photos.map((photo, i) => (
                <div key={photo.id} className="masonry-item group relative">
                  <PhotoView src={photo.url}>
                    <div className="relative rounded-xl overflow-hidden cursor-zoom-in border border-gold-light/50 hover:border-gold transition-all hover:shadow-lg">
                      <Image
                        src={photo.url}
                        alt={photo.caption}
                        width={600}
                        height={400}
                        className="w-full object-cover hover:scale-[1.02] transition-transform duration-500"
                        style={{ aspectRatio: i % 4 === 0 ? '3/4' : i % 3 === 0 ? '4/3' : '1/1' }}
                      />
                      {/* Caption overlay */}
                      <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/50 to-transparent p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-200">
                        <p className="text-white text-xs font-medium truncate">{photo.caption}</p>
                      </div>
                    </div>
                  </PhotoView>

                  {/* Admin delete button */}
                  {isAdmin && (
                    <button
                      onClick={() => handleDelete(photo)}
                      disabled={deleting === photo.id}
                      className="absolute top-2 right-2 w-7 h-7 bg-white/90 hover:bg-rose text-mid hover:text-white rounded-full text-xs items-center justify-center hidden group-hover:flex transition-all shadow"
                    >
                      {deleting === photo.id ? '…' : '✕'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </PhotoProvider>
        )}
      </div>

      <footer className="border-t border-gold-light py-8 text-center mt-12">
        <p className="font-serif italic text-mid text-sm">
          Sanjay & Ananya · June 2025 ♥
        </p>
      </footer>
    </div>
  );
}
