'use client';
import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { uploadPhoto, addPhotoRecord } from '@/lib/firebase';
import { Timestamp } from 'firebase/firestore';
import toast from 'react-hot-toast';

interface FileItem {
  file: File;
  preview: string;
  caption: string;
  progress: number;
  status: 'pending' | 'uploading' | 'done' | 'error';
}

export default function PhotoUploader({
  eventId,
  onUploaded,
}: {
  eventId: string;
  onUploaded: () => void;
}) {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [uploading, setUploading] = useState(false);

  const onDrop = useCallback((accepted: File[]) => {
    const newItems: FileItem[] = accepted.map(f => ({
      file: f,
      preview: URL.createObjectURL(f),
      caption: '',
      progress: 0,
      status: 'pending',
    }));
    setFiles(prev => [...prev, ...newItems]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpg', '.jpeg', '.png', '.webp', '.heic'] },
    multiple: true,
    maxSize: 20 * 1024 * 1024,
  });

  const updateCaption = (idx: number, val: string) => {
    setFiles(prev => prev.map((f, i) => i === idx ? { ...f, caption: val } : f));
  };

  const removeFile = (idx: number) => {
    setFiles(prev => {
      const updated = [...prev];
      URL.revokeObjectURL(updated[idx].preview);
      updated.splice(idx, 1);
      return updated;
    });
  };

  const handleUploadAll = async () => {
    const pending = files.filter(f => f.status === 'pending');
    if (pending.length === 0) return;
    setUploading(true);

    for (let i = 0; i < files.length; i++) {
      if (files[i].status !== 'pending') continue;

      setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'uploading' } : f));

      try {
        const { url, storagePath } = await uploadPhoto(
          files[i].file,
          eventId,
          pct => setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, progress: pct } : f))
        );

        await addPhotoRecord(eventId, {
          url,
          storagePath,
          caption: files[i].caption || files[i].file.name.replace(/\.[^.]+$/, ''),
          fileName: files[i].file.name,
          eventId,
          uploadedAt: Timestamp.now(),
        });

        setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'done', progress: 100 } : f));
      } catch {
        setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'error' } : f));
        toast.error(`Failed to upload ${files[i].file.name}`);
      }
    }

    setUploading(false);
    const doneCount = files.filter(f => f.status === 'pending').length;
    toast.success(`${doneCount} photo${doneCount !== 1 ? 's' : ''} uploaded!`);
    onUploaded();

    // Clear done files after 2s
    setTimeout(() => {
      setFiles(prev => prev.filter(f => f.status !== 'done'));
    }, 2000);
  };

  const pendingCount = files.filter(f => f.status === 'pending').length;

  return (
    <div className="space-y-4">
      {/* Drop zone */}
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
          isDragActive
            ? 'border-gold bg-warm dropzone-active'
            : 'border-gold-light bg-cream hover:border-gold hover:bg-warm'
        }`}
      >
        <input {...getInputProps()} />
        <div className="text-3xl mb-2">📤</div>
        <p className="text-sm text-dark font-medium">
          {isDragActive ? 'Drop photos here...' : 'Drag & drop photos here'}
        </p>
        <p className="text-xs text-mid mt-1">or click to browse — JPG, PNG, WEBP, HEIC up to 20MB each</p>
      </div>

      {/* File list */}
      {files.length > 0 && (
        <div className="space-y-3">
          {files.map((f, i) => (
            <div
              key={i}
              className="flex items-center gap-3 bg-white border border-gold-light rounded-xl p-3"
            >
              {/* Preview */}
              <div className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-warm">
                <img src={f.preview} alt="" className="w-full h-full object-cover" />
              </div>

              {/* Caption input + progress */}
              <div className="flex-1 min-w-0">
                {f.status === 'pending' && (
                  <input
                    type="text"
                    placeholder="Add a caption (optional)"
                    value={f.caption}
                    onChange={e => updateCaption(i, e.target.value)}
                    className="w-full text-sm px-3 py-1.5 border border-gold-light rounded-lg bg-cream text-dark focus:outline-none focus:border-gold"
                  />
                )}
                {f.status === 'uploading' && (
                  <div>
                    <p className="text-xs text-mid mb-1 truncate">{f.file.name}</p>
                    <div className="h-1.5 bg-warm rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gold transition-all duration-300 rounded-full"
                        style={{ width: `${f.progress}%` }}
                      />
                    </div>
                    <p className="text-xs text-mid mt-1">{f.progress}%</p>
                  </div>
                )}
                {f.status === 'done' && (
                  <p className="text-xs text-green-600 font-medium">✓ Uploaded</p>
                )}
                {f.status === 'error' && (
                  <p className="text-xs text-rose font-medium">✗ Failed — try again</p>
                )}
              </div>

              {/* Remove button */}
              {f.status === 'pending' && (
                <button
                  onClick={() => removeFile(i)}
                  className="text-mid hover:text-rose transition-colors text-lg leading-none flex-shrink-0"
                >
                  ×
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Upload button */}
      {pendingCount > 0 && (
        <button
          onClick={handleUploadAll}
          disabled={uploading}
          className="w-full bg-dark text-cream py-3 rounded-xl text-sm font-medium hover:bg-gold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {uploading
            ? 'Uploading...'
            : `Upload ${pendingCount} photo${pendingCount !== 1 ? 's' : ''} →`}
        </button>
      )}
    </div>
  );
}
