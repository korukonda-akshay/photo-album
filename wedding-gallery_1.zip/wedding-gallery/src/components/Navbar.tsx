'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAdmin } from '@/lib/adminAuth';
import { useState } from 'react';
import toast from 'react-hot-toast';

export default function Navbar() {
  const { isAdmin, login, logout } = useAdmin();
  const pathname = usePathname();
  const [showLogin, setShowLogin] = useState(false);
  const [pw, setPw] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(pw)) {
      toast.success('Welcome, admin!');
      setShowLogin(false);
      setPw('');
    } else {
      toast.error('Wrong password');
    }
  };

  return (
    <>
      <nav className="sticky top-0 z-50 bg-cream/90 backdrop-blur-md border-b border-gold-light">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Brand */}
          <Link href="/" className="font-serif text-xl text-dark tracking-wide hover:opacity-80 transition-opacity">
            Sanjay <span className="italic text-gold">&</span> Ananya
          </Link>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {pathname !== '/' && (
              <Link
                href="/"
                className="text-sm text-mid hover:text-dark transition-colors px-3 py-1.5 rounded-full border border-gold-light hover:border-gold hover:bg-warm"
              >
                ← All Events
              </Link>
            )}

            {isAdmin ? (
              <div className="flex items-center gap-2">
                <Link
                  href="/admin"
                  className={`text-sm px-3 py-1.5 rounded-full border transition-all ${
                    pathname === '/admin'
                      ? 'bg-dark text-cream border-dark'
                      : 'border-gold-light text-mid hover:border-gold hover:bg-warm'
                  }`}
                >
                  ⚙ Admin
                </Link>
                <button
                  onClick={() => { logout(); toast('Logged out'); }}
                  className="text-sm text-mid hover:text-rose transition-colors"
                >
                  Sign out
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowLogin(true)}
                className="text-sm px-3 py-1.5 rounded-full border border-gold-light text-mid hover:border-gold hover:bg-warm transition-all"
              >
                Admin
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Login modal */}
      {showLogin && (
        <div
          className="fixed inset-0 z-[200] bg-dark/70 flex items-center justify-center p-4"
          onClick={e => { if (e.target === e.currentTarget) setShowLogin(false); }}
        >
          <div className="bg-cream rounded-2xl p-8 w-full max-w-sm shadow-2xl">
            <h2 className="font-serif text-2xl text-dark mb-1">Admin Login</h2>
            <p className="text-sm text-mid mb-6">Enter your admin password to manage the gallery.</p>
            <form onSubmit={handleLogin} className="flex flex-col gap-3">
              <input
                type="password"
                placeholder="Password"
                value={pw}
                onChange={e => setPw(e.target.value)}
                autoFocus
                className="w-full px-4 py-2.5 rounded-xl border border-gold-light bg-white text-dark text-sm focus:outline-none focus:border-gold"
              />
              <button
                type="submit"
                className="bg-dark text-cream py-2.5 rounded-xl text-sm font-medium hover:bg-gold transition-colors"
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => setShowLogin(false)}
                className="text-sm text-mid hover:text-dark transition-colors"
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
