'use client';
import Link from 'next/link';
import Image from 'next/image';
import { WeddingEvent } from '@/lib/firebase';

interface EventCardProps {
  event: WeddingEvent;
  index: number;
}

export default function EventCard({ event, index }: EventCardProps) {
  return (
    <Link
      href={`/event/${event.id}`}
      className="group block bg-white rounded-2xl border border-gold-light overflow-hidden hover:-translate-y-1.5 hover:shadow-xl hover:border-gold transition-all duration-300"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Cover image / fallback */}
      <div
        className="h-44 relative overflow-hidden flex items-center justify-center"
        style={{ background: event.color }}
      >
        {event.coverPhoto ? (
          <Image
            src={event.coverPhoto}
            alt={event.name}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <span className="text-5xl select-none">{event.emoji}</span>
        )}

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />

        {/* Photo count badge */}
        <div className="absolute top-3 right-3 bg-cream/90 border border-gold-light text-mid text-xs px-2.5 py-1 rounded-full font-medium">
          {event.photoCount ?? 0} photos
        </div>
      </div>

      {/* Info */}
      <div className="px-4 pt-3 pb-4 relative">
        <h3 className="font-serif text-[20px] text-dark leading-tight">{event.name}</h3>
        <p className="text-xs text-mid mt-0.5">{event.date}</p>

        {/* Arrow */}
        <span className="absolute bottom-4 right-4 text-gold text-sm opacity-0 group-hover:opacity-100 translate-x-[-4px] group-hover:translate-x-0 transition-all duration-200">
          →
        </span>
      </div>
    </Link>
  );
}
