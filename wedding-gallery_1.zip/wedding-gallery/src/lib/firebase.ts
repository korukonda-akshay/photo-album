import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  getDocs,
  addDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  Timestamp,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
} from 'firebase/storage';

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const db = getFirestore(app);
export const storage = getStorage(app);

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Photo {
  id: string;
  url: string;
  caption: string;
  fileName: string;
  storagePath: string;
  uploadedAt: Timestamp;
  eventId: string;
}

export interface WeddingEvent {
  id: string;
  name: string;
  date: string;
  emoji: string;
  color: string;
  coverPhoto?: string;
  photoCount?: number;
}

// ─── Default events (seeded on first load) ───────────────────────────────────

export const DEFAULT_EVENTS: Omit<WeddingEvent, 'id'>[] = [
  { name: 'Engagement',  date: 'March 12, 2025', emoji: '💍', color: '#fce4ec' },
  { name: 'Haldi',       date: 'June 3, 2025',   emoji: '🌼', color: '#fff9c4' },
  { name: 'Mehendi',     date: 'June 4, 2025',   emoji: '🌿', color: '#e8f5e9' },
  { name: 'Wedding',     date: 'June 6, 2025',   emoji: '👰', color: '#fce4ec' },
  { name: 'Reception',   date: 'June 7, 2025',   emoji: '🎉', color: '#ede7f6' },
];

// ─── Firestore helpers ────────────────────────────────────────────────────────

export async function getEvents(): Promise<WeddingEvent[]> {
  const snap = await getDocs(collection(db, 'events'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as WeddingEvent));
}

export async function getPhotos(eventId: string): Promise<Photo[]> {
  const q = query(
    collection(db, 'events', eventId, 'photos'),
    orderBy('uploadedAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Photo));
}

export async function addPhotoRecord(eventId: string, data: Omit<Photo, 'id'>) {
  return addDoc(collection(db, 'events', eventId, 'photos'), data);
}

export async function deletePhoto(eventId: string, photo: Photo) {
  await deleteDoc(doc(db, 'events', eventId, 'photos', photo.id));
  const storageRef = ref(storage, photo.storagePath);
  await deleteObject(storageRef);
}

export async function seedEvents() {
  const existing = await getEvents();
  if (existing.length > 0) return;
  for (const event of DEFAULT_EVENTS) {
    await addDoc(collection(db, 'events'), event);
  }
}

// ─── Storage upload with progress ────────────────────────────────────────────

export function uploadPhoto(
  file: File,
  eventId: string,
  onProgress: (pct: number) => void
): Promise<{ url: string; storagePath: string }> {
  return new Promise((resolve, reject) => {
    const path = `events/${eventId}/${Date.now()}_${file.name}`;
    const storageRef = ref(storage, path);
    const task = uploadBytesResumable(storageRef, file);

    task.on(
      'state_changed',
      snap => onProgress(Math.round((snap.bytesTransferred / snap.totalBytes) * 100)),
      reject,
      async () => {
        const url = await getDownloadURL(task.snapshot.ref);
        resolve({ url, storagePath: path });
      }
    );
  });
}
