'use client';
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AdminCtx {
  isAdmin: boolean;
  login: (pw: string) => boolean;
  logout: () => void;
}

const AdminContext = createContext<AdminCtx>({
  isAdmin: false,
  login: () => false,
  logout: () => {},
});

export function AdminProvider({ children }: { children: ReactNode }) {
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setIsAdmin(sessionStorage.getItem('admin') === 'true');
  }, []);

  const login = (pw: string) => {
    const correct = pw === process.env.NEXT_PUBLIC_ADMIN_PASSWORD;
    if (correct) {
      sessionStorage.setItem('admin', 'true');
      setIsAdmin(true);
    }
    return correct;
  };

  const logout = () => {
    sessionStorage.removeItem('admin');
    setIsAdmin(false);
  };

  return (
    <AdminContext.Provider value={{ isAdmin, login, logout }}>
      {children}
    </AdminContext.Provider>
  );
}

export const useAdmin = () => useContext(AdminContext);
